/*
   To define your AngularJS extensions for the custom templates in Mindbender,
   your own JavaScript/CoffeeScript code can be put at mindbender/extensions.js
   or mindbender/extensions.coffee file under the working directory where you
   start `mindbender gui`.  All files under the mindbender/ directory will be
   available under the same relative path, e.g., an AngularJS template stored
   in mindbender/foo.html will be available as "mindbender/foo.html".  Hence,
   you can use arbitrary number of files to define your extensions.
*/

//angular.module("mindbender.extensions", [
//])

// .directive("fooBar", function($location){
//     return {
//     // TODO
//     };
// }

// .filter("usefulThing", function(){
//     return function(input, arg, arg2) {
//     // TODO
//     };
// }

;
