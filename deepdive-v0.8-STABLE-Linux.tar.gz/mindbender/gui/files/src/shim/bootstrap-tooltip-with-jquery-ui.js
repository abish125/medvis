// See: http://stackoverflow.com/a/19247955/390044
// Must be put between jquery-ui.js and bootstrap.js
$.widget.bridge("uibutton", $.ui.button);
$.widget.bridge("uitooltip", $.ui.tooltip);
