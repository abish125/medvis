// XXX this shim is to make the angular code less ugly
ace.config.set("basePath", "bower_components/ace-builds/src-noconflict/");
